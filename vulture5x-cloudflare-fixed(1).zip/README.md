# Vulture5x — Cloudflare Worker

## Required repository layout

Keep these files at the GitHub repository root. The `public/` folder must contain your website, including `public/index.html`.

```text
/
├── .github/workflows/deploy-cloudflare.yml
├── public/
│   └── index.html   # add your actual website files here
├── .gitignore
├── package.json
├── README.md
├── worker.js
└── wrangler.jsonc
```

## Local development

Install Node.js LTS, then run:

```bash
npm install
npx wrangler login
npm run dev
```

## Deploy manually

```bash
npm install
npm run check
npm run deploy
```

Wrangler is pinned to version `4.135.0`.

## GitHub → Cloudflare automatic deployment

Add these repository Actions secrets under **GitHub → Settings → Secrets and variables → Actions**:

- `CLOUDFLARE_API_TOKEN`: API token permitted to deploy Workers.
- `CLOUDFLARE_ACCOUNT_ID`: your Cloudflare account ID.

Push to `main` to trigger deployment. In Cloudflare Workers Builds, set the root directory to the repository root (blank or `/`, depending on the dashboard), not `public` or `dist`. The workflow below deploys through GitHub Actions instead of relying on dashboard build settings.

## Important

The `public/` directory and your actual website files were not among the files provided for this repair. Add/commit the real website files into `public/` before deploying, or Wrangler will report that the assets directory does not exist. Do not replace your existing website with a blank placeholder.

This is a Cloudflare Worker project, not a GitHub Pages deployment. GitHub Pages cannot run `worker.js`, which provides the Twitch API proxy.
